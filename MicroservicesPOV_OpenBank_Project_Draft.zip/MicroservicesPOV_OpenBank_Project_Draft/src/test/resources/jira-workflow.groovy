//created by Himanshu for JIRA workflow statuses

when 'To Do', {
    'SUCCESS' should: 'Done'
}

when 'To Do', {
    'FAILURE' should: 'To Do'
}

when 'Done', {
    'FAILURE' should: 'To Do'
}

when 'In Progress', {
    'SUCCESS' should: 'Done'
}

when 'In Progress', {
    'FAILURE' should: 'To Do'
}

when 'Done', {
    'SUCCESS' should: 'Done'
}

