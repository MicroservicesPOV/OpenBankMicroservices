package driverScript;


/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */


import net.serenitybdd.jbehave.SerenityStories;
import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.BeforeStory;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class RunnerTestSuite extends SerenityStories {

    private final String SYSTEM_PROPERTIES_FILE_NAME = "selenide.properties";

   //mvn clean -Dit.test=RunnerSuite verify

    @BeforeStory
    public void beforeStory() {
      //  setupGlobalProperties();

    }


    //Uncomment to run series of stories
    @Override
    public List<String> storyPaths() {
        File file = new File(System.getProperty("user.dir").concat("\\src\\test\\resources\\story_order.txt"));
        try (FileReader reader = new FileReader(file)) {
            char[] buffer = new char[(int) file.length()];
            reader.read(buffer);
            String[] lines = new String(buffer).split("\n");
            List<String> storiesList = new ArrayList<>(lines.length);
            for (String line : lines) {
                if ((line.length() > 1) && (!line.startsWith("#"))) {
                    storiesList.add(line.trim());
                }
            }
            return storiesList;
        }
        catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected String getStoryPath() {
        findStoriesCalled("**/*included.story");
        return super.getStoryPath();
    }

    @AfterScenario
    public void afterScenario() {

    }

   /* private void setupGlobalProperties() {
        Properties properties = new Properties();
        String path = getPath() + SYSTEM_PROPERTIES_FILE_NAME;
        FileInputStream propFile;
        try {
            propFile = new FileInputStream(path);
            properties.load(propFile);
        } catch (IOException e) {
            throw new Error("Failed to read properties file '" + SYSTEM_PROPERTIES_FILE_NAME+"': "+e.getMessage(), e);
        }

        @SuppressWarnings("unchecked")
        Enumeration<String> e = (Enumeration<String>) properties.propertyNames();
        while (e.hasMoreElements()) {
            String key = e.nextElement();
            System.setProperty(key, properties.getProperty(key));
        }
    }*/

    private String getPath(){
        String classPath = getClass().getClassLoader().getResource("").getPath();
        return classPath.replaceAll("\\.", "/");
    }

    @Override
    protected String getRootPackage() {
        return "storySteps";
    }
}
