package actionSteps;

/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */

import net.thucydides.core.annotations.Step;

// This method prints the custom message in the serenity report's step

public class log {

    @Step()
    public void StepMessage(String message){

    }



}
