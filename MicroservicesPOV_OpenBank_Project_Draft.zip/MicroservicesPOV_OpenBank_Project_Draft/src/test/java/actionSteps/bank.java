package actionSteps;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.thucydides.core.annotations.Step;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.WithTag;
import org.junit.Assert;
import java.util.ArrayList;
import java.util.List;
import static io.restassured.RestAssured.given;


/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */


public class bank {

    Response response = null;
    BaseTest baseTest = new BaseTest();
    baseFunctions basefunction= new baseFunctions();

    @Step
    public void requestListOfBranchesOfBank() {}


    @Step
    public Response returnListOfBranchesOfBank(String Token)
    {
        Response response =
                SerenityRest.
                        given().
                        header("Authorization",Token).
                        contentType("application/json").
                        when().
                        get(baseTest.baseURL +"/obp/v3.0.0/banks");

        return response;
    }



    @Step
    public void validateBankIdPresence(String Token , Response bankList, String BANK_ID)
    {
        JsonPath jsonpathEvaluator = bankList.jsonPath();
        List<String> bankIds = new ArrayList<String>();
        bankIds = jsonpathEvaluator.get("banks.id");
        Assert.assertEquals("Branch Id NOT Found", bankIds.contains(BANK_ID), true);
        System.out.println("Bank Ids are: " +bankIds);
    }


}
