package actionSteps;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.ProxySpecification;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.WithTag;
import org.joda.time.DateTime;
import org.junit.Assert;

import java.text.SimpleDateFormat;
import java.util.Date;

import static io.restassured.RestAssured.proxy;

/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */

public class baseFunctions {

    Response response = null;
    static BaseTest baseTest = new BaseTest();


    public static String GenarateToken()
    {

         Response response=
                SerenityRest
                .given()
                .header("Authorization","DirectLogin username=\""+baseTest.obp_UserName+"\",password=\""+baseTest.obp_Password+"\", consumer_key=\""+baseTest.obp_ConsumerKey+"\"")
                .contentType("application/json")
                .when()
                .post(baseTest.baseURL+"/my/logins/direct1");

        System.out.println(response.statusCode());
        System.out.println(response.body().prettyPrint());
        Assert.assertEquals(  "Error in generating Token.Authentication Failed!", 201 ,response.statusCode());
        JsonPath jsonpathEvaluator = response.jsonPath();
        String token= jsonpathEvaluator.get("token");
        System.out.println("Token is: " +token);
        String Completetoken= "DirectLogin token=" + token;

        return Completetoken;

    }


    @Step
    public void log(String message) {
    }


    public String generateRandomAccountId (){

        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMddHHmmss");//dd/MM/yyyy
        Date now = new Date();
        String strDate = sdfDate.format(now);
        String acct_id = "AutoCreatedDemoAcctId_"+ strDate;

        return acct_id;

    }

    @Step
    public Response requestUserInfo(String Token) {

        Response response =
                SerenityRest.
                        given().
                        header("Authorization", Token).
                        contentType("application/json").
                        when().
                        get(baseTest.baseURL + "/obp/v3.0.0/users/current");

        System.out.println(response.statusCode());
        System.out.println(response.prettyPrint());
        return response;

    }

    @Step
    public String returnUserId( Response userInfoResponse ){

        JsonPath jsonpathEvaluator = userInfoResponse.jsonPath();
        String userId= jsonpathEvaluator.get("user_id");
        System.out.println("UserId is: " +userId);
        log("UserId is: " +userId);
        return userId;
    }


}
