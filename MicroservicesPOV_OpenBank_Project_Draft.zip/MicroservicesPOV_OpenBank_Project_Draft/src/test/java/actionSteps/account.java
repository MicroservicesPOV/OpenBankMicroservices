package actionSteps;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.ProxySpecification;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static io.restassured.RestAssured.given;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.ProxySpecification;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */
public class account {

    Response response = null;
    BaseTest baseTest = new BaseTest();
    baseFunctions basefunction= new baseFunctions();

    @Step
    public Response getAllAcctsInBankBranch(String Token, String bank_id)
    {
        Response response =
                SerenityRest.
                given().
                header("Authorization",Token).
                contentType("application/json").
                when().
                get(baseTest.baseURL +"/obp/v2.0.0/banks/"+bank_id+"/accounts");
        return response;
    }

    @Step
    public Response createAccount(String Token, String bank_id , String Account_ID , String user_id , String Acct_label)
    {
        Response response =
                SerenityRest.
                given().
                header("Authorization",Token).
                contentType("application/json").
                body("{  \"user_id\":\""+user_id+"\",  \"label\":\""+Acct_label+"\",  \"type\":\"CURRENT\",  \"balance\":{    \"currency\":\"USD\",    \"amount\":\"0\"  },  \"branch_id\":\"1234\",  \"account_routing\":{    \"scheme\":\"OBP\",    \"address\":\"UK1234567\"  }}").
                when().
                put(baseTest.baseURL+"/obp/v3.0.0/banks/"+bank_id+"/accounts/"+Account_ID);

        System.out.println(response.statusCode());
        System.out.println(response.prettyPrint());
        return response;
    }


        @Step
        public void validateCreatedAccountExistence(Response acctListResponse , String acct_id )
        {
            JsonPath jsonpathEvaluator = acctListResponse.jsonPath();
            List<String> acctIds = new ArrayList<String>();
            acctIds = jsonpathEvaluator.get("id");
            Assert.assertEquals("Account Id: "+ acct_id+ "NOT Found", true, acctIds.contains(acct_id));
            System.out.println("Acct Ids are: " +acctIds);


        }




    }




