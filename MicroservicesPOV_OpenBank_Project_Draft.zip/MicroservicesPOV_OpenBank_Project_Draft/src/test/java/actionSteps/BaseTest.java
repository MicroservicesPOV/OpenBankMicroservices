package actionSteps;


import net.thucydides.core.annotations.Step;

/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */


public class BaseTest {

    String baseURL="https://bnpparibas-api.openbankproject.com";

    // Below credentials for registered users to get Authorization
    String obp_UserName = "hbiswas87";
    String obp_Password = "P@ssw0rd123";
    String obp_ConsumerKey = "sh3b2jl4g3zemwlhv5l0cjrawjajdarciekqutgl";
}
