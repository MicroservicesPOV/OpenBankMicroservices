package storySteps;

import actionSteps.account;
import actionSteps.baseFunctions;
import actionSteps.log;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.SerenityReports;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.annotations.WithTag;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import static org.junit.Assert.assertEquals;

/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */

public class createAccount {

    baseFunctions basefunction= new baseFunctions();
    account Account= new account();
    String Token= "";
    String USER_ID = "";
    Response userInfoResponse;
    Response createAccountResponse;
    String randomAcctId = "";

    @Steps
    log log;


    @Given("I as an authorized user who can create an account")
    public void generateTokenAndGetUserIdForUser(){

        Token=basefunction.GenarateToken();
        userInfoResponse =  basefunction.requestUserInfo(Token);
        Assert.assertEquals("Error in getting User info", 200, userInfoResponse.statusCode());
        USER_ID = basefunction.returnUserId(userInfoResponse);

    }


    @When("I request to create an account with label : $Acct_label under BNP Paribas bank branch : $bank_id")
    public Response createAccount(String bank_id , String Acct_label){
        randomAcctId = basefunction.generateRandomAccountId();
        createAccountResponse = Account.createAccount(Token , bank_id ,  randomAcctId, USER_ID , Acct_label );
        return createAccountResponse;
    }


    @Then("the new account should get created under bank branch : $BANK_ID")
    public void verifyResponse(String bank_id){
        assertEquals(200, createAccountResponse.statusCode());
        Response acctListResponse = Account.getAllAcctsInBankBranch(Token, bank_id);
        Account.validateCreatedAccountExistence(acctListResponse , randomAcctId);
        log.StepMessage("Account id  <" + randomAcctId + "> is present in the below list :"+"\n"+ acctListResponse.body().prettyPrint());

    }

}
