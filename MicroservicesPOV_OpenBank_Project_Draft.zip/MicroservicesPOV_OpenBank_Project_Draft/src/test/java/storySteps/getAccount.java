package storySteps;

import actionSteps.account;
import actionSteps.baseFunctions;
import io.restassured.response.Response;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.Assert.assertEquals;

/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */

public class getAccount {

    baseFunctions basefunction= new baseFunctions();
    account Account= new account();
    createAccount createAccount = new createAccount();
    String Token= "";
    Response acctList;

    @Given("I as an authorized user who can view accounts")
    public void generateTokenForUser(){

        Token=basefunction.GenarateToken();

    }



    @When("I request to get list of all accounts registered under bank branch: $bank_id")
    public Response getAccountList(String bank_Id){
        acctList = Account.getAllAcctsInBankBranch(Token, bank_Id);
        assertEquals(200, acctList.statusCode());
        return acctList;
    }



}
