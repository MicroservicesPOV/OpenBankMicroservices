package storySteps;

import actionSteps.log;
import actionSteps.bank;
import actionSteps.baseFunctions;
import io.restassured.response.Response;
import net.thucydides.core.annotations.Steps;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static org.junit.Assert.assertEquals;

/**
 * Created by Himanshu Biswas(Cognizant) on 27/04/2018.
 */

public class getBranchesOfBank {


    bank Bank = new bank();
    baseFunctions basefunction = new baseFunctions();
    String Token = "";
    Response listOfBankBranches;

    @Steps
    log log;

    @Given("I as an authorized user who has bank locator role")
    public void generateTokenForUser(){
        Token=basefunction.GenarateToken();
    }


    @When("I request to get the list of all global bank branches")
    public void getBranchList(){
        listOfBankBranches =  Bank.returnListOfBranchesOfBank(Token);

        }


    @Then("bank id: '$BANK_ID' should exist in the list of banks")
    public void verifyBankIdExistence( String BANK_ID){
        Bank.validateBankIdPresence( Token , listOfBankBranches ,  BANK_ID) ;
        log.StepMessage("Bank id  <" + BANK_ID + "> is present in the below list :"+"\n"+ listOfBankBranches.body().prettyPrint());

    }



}
